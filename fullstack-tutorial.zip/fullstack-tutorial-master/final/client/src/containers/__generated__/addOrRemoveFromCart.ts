/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: addOrRemoveFromCart
// ====================================================

export interface addOrRemoveFromCart {
  addOrRemoveFromCart: string[];
}

export interface addOrRemoveFromCartVariables {
  launchId: string;
}
