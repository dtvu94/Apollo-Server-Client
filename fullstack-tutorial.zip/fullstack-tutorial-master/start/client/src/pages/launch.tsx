import React from 'react';
import { RouteComponentProps } from '@reach/router';

interface LaunchProps extends RouteComponentProps {

}

const Launch: React.FC<LaunchProps> = () => {
  return <div />;
}

export default Launch;
