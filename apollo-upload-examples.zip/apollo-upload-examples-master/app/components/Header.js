export const Header = (props) => (
  <>
    <header {...props} />
    <style jsx>{`
      header {
        margin: var(--daui-spacing);
      }
    `}</style>
  </>
);
