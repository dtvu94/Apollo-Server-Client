module.exports = {
  env: {
    API_URI: process.env.API_URI,
  },
};
